import os

# Bien cuc bo
y = 0


# Ham tinh nghịch đảo
def timNghichDao2So(a, b):
    a2, b2 = 0, 1
    a3, b3 = a, b
    q, r3, r2 = 0, 0, 0

    while r3 != 1:
        q, r3 = a3 // b3, a3 % b3
        r2 = a2 - b2 * q

        # Đổi chỗ
        a3, b3 = b3, r3
        a2, b2 = b2, r2
    if r2 < 0:
        r2 += a
    return r2


# Hàm kiểm tra số nguyên tố
def KT_SoNT(x):
    if x < 2: return 0
    for i in range(2, x):
        if x % i == 0:
            return 1
    return 0


# Hàm tìm khóa
def timKhoa(p, g, u):
    global y
    y = g ** u % p
    Kp = (p, g, y)
    Ks = u
    key = (Kp, Ks)
    return key


# Hàm mã hóa
def maHoa(p, g, k, x):
    a = g ** k % p
    b = (y ** k * x) % p
    code = (a, b)
    return code


# Hàm giải mã
def giaiMa(p, u, h):
    a, b = h[0], h[1]
    tg = a ** u % p
    z = tg * b % p
    return z

if __name__ == '__main__':
    p, g, u, k, x = 13, 5, 6, 7, 4

    a = timKhoa(p, g, u)
    b = maHoa(p, g, k, x)
    c = giaiMa(p, u, b)

    print("Khoa phu va khoa chinh la: ", a)
    print("y: ", y)
    print("Ma hoa cua x = 4 la: ", b)
    print("Giai ma: ", c)
