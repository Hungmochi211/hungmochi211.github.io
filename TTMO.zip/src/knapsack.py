import os
#Bien cuc bo
a2,u2,c1 = [],0,0

#Ham tinh nghịch đảo
def timNghichDao2So(a,b):
    a2,b2 = 0,1
    a3,b3 = a,b
    q, r3, r2 = 0,0,0

    while r3 != 1:
        q,r3 = a3 // b3, a3 %b3
        r2 = a2-b2 *q
        
        #Đổi chỗ
        a3,b3 = b3,r3
        a2,b2 = b2,r2
    if r2 < 0:
        r2 += a
    return r2

#Hàm tìm khóa
def timKhoa(a1,m,u1):
    global a2,u2

    for i in range(len(a1)):
        a2.append(a1[i]*u1%m)
    u2 = timNghichDao2So(m,u1)
    Kp = (a2,m)
    Ks = (u1,u2)
    key = (Kp,Ks)
    return key        

#Hàm mã hóa
def maHoa(m,p):
    global c1

    for i in range (len(p)):
        c1 += int(p[i])*a2[i]
    c1 %= m
    return c1

#Hàm giải mã
def giaiMa(a1,m):
    c2 = c1*u2%m
    x = [None]*len(a1)
    t,a2 = c2,a1.copy()
    for i in range(len(a2)):
        value = max(a2)
        key = a1.index(value)
        if t >= value:
            x[key] = 1
            t = t - value
        else:
            x[key] = 0
        a2.remove(value)
    return x

if '__main__' == __name__:
    a = [2,3,6,12,25]
    p = [0,1,0,0,1]
    M,u,u1 = 53,46,15

    x = timKhoa(a,M,u)
    y = maHoa(M,p)
    z = giaiMa(a,M)

    print("Khoa phu va khoa chinh la: ",x)
    print("Ma hoa cua x = 01001 la: ",y)
    print("Giai ma: ",z)

