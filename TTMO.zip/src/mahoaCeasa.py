banro = input('ban ro la gi?: ')
khoa = int(input('Khoa la bao nhieu k = ')) #chưa xử lí khóa k > 26
banma = ""

for ch in banro:
    vitri = ord(ch) + khoa
    if(64<ord(ch)<91 and (vitri in range(65,91))) or 96<ord(ch)<123 and (vitri in range(97,123)):
        chumoi = chr(vitri)
    else:
        vitrimoi = vitri-26
        chumoi = chr(vitrimoi)
    banma = banma +chumoi

print('ban ma la: ',banma)