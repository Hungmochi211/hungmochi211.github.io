package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Books;

public class BookDAO {
	
	//Lay danh sach
	public List<Books> getAllBooks() {
		List<Books> booksList = new ArrayList<>();
		String sql = "SELECT * FROM tblbook";
		
		try(Connection conn = DBConnect.getConnection();Statement stmt = conn.createStatement();ResultSet rs = stmt.executeQuery(sql)){
			while (rs.next()) {
				Books books = new Books(rs.getString("idsach"),rs.getString("Tensach"),rs.getString("Tacgia"),rs.getFloat("Gia"),rs.getInt("Uutien"));
				booksList.add(books);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return booksList;
	}
	
	//Them sach
	public boolean addBooks(Books books) {
		String sql = "INSERT INTO tblbook (idsach, Tensach, Tacgia, Gia, Uutien) VALUES (?,?,?,?,?)";
		try(Connection conn = DBConnect.getConnection();PreparedStatement stmt = conn.prepareStatement(sql)){
			
			stmt.setString(1, books.getIdsach());
			stmt.setString(2, books.getTensach());
			stmt.setString(3, books.getTacgia());
			stmt.setFloat(4, books.getGia());
			stmt.setInt(5, books.getUutien());
			
			return stmt.executeUpdate() > 0;
			
		}catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	//sua sach
	public boolean updateBooks(Books books) {
		String sql = "UPDATE tblbook SET idsach = ?,Tensach = ?,Tacgia = ?,Gia = ?,Uutien = ? WHERE idsach = ?";
		try(Connection conn = DBConnect.getConnection();PreparedStatement stmt = conn.prepareStatement(sql)){
			
			stmt.setString(1, books.getIdsach());
			stmt.setString(2, books.getTensach());
			stmt.setString(3, books.getTacgia());
			stmt.setFloat(4, books.getGia());
			stmt.setInt(5, books.getUutien());
			stmt.setString(6, books.getIdsach());
			
			return stmt.executeUpdate() > 0;
			
		}catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	//xoa sach
	public boolean deleteBooks(String id) {
		String sql = "DELETE FROM tblbook WHERE idsach = ?";
		try(Connection conn = DBConnect.getConnection();PreparedStatement stmt = conn.prepareStatement(sql)){
			
			stmt.setString(1,id);
			
			return stmt.executeUpdate() > 0;
			
		}catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	//tim sach theo ma
	public Books getBooksById(String id) {
		Books books = null;
		String sql = "SELECT * FROM tblbook WHERE idsach = ?";
		try(Connection conn = DBConnect.getConnection();PreparedStatement stmt = conn.prepareStatement(sql)){
			
			stmt.setString(1, id);
			
			try (ResultSet rs = stmt.executeQuery()){
				if(rs.next()) {
					books = new Books(rs.getString("idsach"), rs.getString("Tensach"), rs.getString("Tacgia"),rs.getFloat("Gia"),rs.getInt("Uutien"));
				}
			}
				
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return books;
	}
}
