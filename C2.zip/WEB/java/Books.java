package model;

public class Books {
    private String idsach;
    private String tensach;
    private String tacgia;
    private float gia;
    private int uutien;

    public Books(String idsach, String tensach, String tacgia, float gia, int uutien) {
        this.idsach = idsach;
        this.tensach = tensach;
        this.tacgia = tacgia;
        this.gia = gia;
        this.uutien = uutien;
    }

    public String getIdsach() {
        return idsach;
    }

    public String getTensach() {
        return tensach;
    }

    public String getTacgia() {
        return tacgia;
    }

    public float getGia() {
        return gia;
    }

    public int getUutien() {
        return uutien;
    }

    public void setIdsach(String idsach) {
        this.idsach = idsach;
    }

    public void setTensach(String tensach) {
        this.tensach = tensach;
    }

    public void setTacgia(String tacgia) {
        this.tacgia = tacgia;
    }

    public void setGia(float gia) {
        this.gia = gia;
    }

    public void setUutien(int uutien) {
        this.uutien = uutien;
    }
}
