SELECT * FROM tblbook

INSERT INTO tblbook (idsach, Tensach, Tacgia, Gia, Uutien)
VALUES ('S02', 'Cách Tán gái NEU','Trần Mạnh Hùng', 250000,1);

INSERT INTO tblbook (idsach, Tensach, Tacgia, Gia, Uutien)
VALUES ('S03', 'Cách chơi valorant','Trần Mạnh Hùng', 300000,2);

INSERT INTO tblbook (idsach, Tensach, Tacgia, Gia, Uutien)
VALUES ('S04', 'Cách code warcraft','Trần Mạnh Hùng', 300000,1);

UPDATE tblbook SET idsach = ?,Tensach = ?,Tacgia = ?,Gia = ?,Uutien = ? WHERE idsach = ?
DELETE FROM tblbook WHERE idsach = ?
SELECT * FROM tblbook WHERE idsach = ?