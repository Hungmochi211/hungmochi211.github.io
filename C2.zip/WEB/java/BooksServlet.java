package controller;

import model.Books;
import dao.BookDAO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BooksServlet extends HttpServlet {
	
	public static BookDAO bookDAO =  new BookDAO();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    req.setCharacterEncoding("UTF-8");
	    resp.setCharacterEncoding("UTF-8");

	    String action = req.getParameter("action");
	    String idsach = req.getParameter("idsach");
	    if (action == null) action = "list";

	    switch (action) {
			default:
				List<Books> list = bookDAO.getAllBooks();
				req.setAttribute("bookList", list);
				req.getRequestDispatcher("list.jsp").forward(req, resp);
				break;
			case "add":
				req.getRequestDispatcher("form.jsp").forward(req, resp);
				break;
			case "edit":
				String isEdit = idsach;
                Books editBooks = bookDAO.getBooksById(isEdit);
                req.setAttribute("books", editBooks);
				req.getRequestDispatcher("form.jsp").forward(req, resp);
				break;
			case "delete":
				String isDelete = idsach;
				Boolean succesDl = bookDAO.deleteBooks(isDelete);
			    if (succesDl) {
			        resp.sendRedirect("books?msg=deleteSuccess");
			    } else {
			        resp.sendRedirect("books?msg=deleteFail");
			    }
				break;
			case "search":
				String isFind = idsach;
				List<Books> bookList = new ArrayList<Books>();
				Books book = bookDAO.getBooksById(isFind);
				if (book != null) {
					bookList.add(book);
					req.setAttribute("bookList", bookList);
					req.getRequestDispatcher("list.jsp").forward(req, resp);
				} else {
					resp.sendRedirect("books?msg=findFail");
				}
				break;
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
        
        //Dữ liệu lấy được từ form
        String idsach = req.getParameter("idsach");
        String tensach = req.getParameter("tensach");
        String tacgia = req.getParameter("tacgia");
        float gia = Float.parseFloat(req.getParameter("gia"));
        int uutien = Integer.parseInt(req.getParameter("uutien"));
        
        //Goi vào 1 đối tượng	
        Books book = new Books(idsach,tensach , tacgia, gia, uutien);
        String action = req.getParameter("action");
        if (action == null) action = "list";
        
        switch (action) {
			case "add":
				Boolean successAD = bookDAO.addBooks(book);
				if (successAD) {
					//bt
					float thanhtien = 0;
					if (uutien == 1) thanhtien = gia + (0.02f * gia);
			        else if (uutien == 2) thanhtien = gia + (0.05f * gia);
					resp.sendRedirect("books?msg=addSuccess&thanhtien=" + thanhtien);
				} else {
					resp.sendRedirect("books?msg=addFail");
				}
				break;
			case "edit":
				Boolean successED = bookDAO.updateBooks(book);
				if (successED) {
					resp.sendRedirect("books?msg=editSuccess");
				} else {
					resp.sendRedirect("books?msg=editFail");
				}
				break;
		}

	}
}
