const idsach = document.getElementById("masach");
const tensach = document.getElementById("tensach");
const tacgia = document.getElementById("tacgia");
const nhomuutien = document.getElementById("nhomuutien");

const btnThem = document.getElementById("btnThemSach");
const btnReturn = document.getElementById("btnLamMoi");
const btnBack = document.getElementById("btnQuayLai");

function kiemTraIdSach() {
    const v = idsach.value.trim();
    if (v.length > 10) {
        alert("ID sách tối đa 10 ký tự");
        idsach.value = "";
    }
}

function kiemTraTenSach() {
    const v = tensach.value.trim();
    if (v.length > 50) {
        alert("Tên sách tối đa 50 ký tự");
        tensach.value = "";
    }
}

function kiemTraTacGia() {
    const v = tacgia.value.trim();
    if (v.length > 40) {
        alert("Tác giả tối đa 40 ký tự");
        tacgia.value = "";
    }
}

function kiemTraNhomUuTien() {
    const v = nhomuutien.value.trim();
    if (v !== "1" && v !== "2") {
        alert("Nhóm ưu tiên chỉ được nhập 1 hoặc 2");
        nhomuutien.value = "";
    }
}

btnThem.addEventListener("click", () => {
    window.location.href = "books?action=add";
});

if (btnBack) {
    btnBack.addEventListener("click", () => {
        window.location.href = "books";
    });
}

if (btnReturn) {
    btnReturn.addEventListener("click", () => {
        window.location.href = "books";
    });
}


document.addEventListener("DOMContentLoaded", function() {

    const params = new URLSearchParams(window.location.search);
	const thanhtien = params.get("thanhtien");

    if (params.get("msg") === "deleteSuccess") {
        alert("Xóa sách thành công!");
		window.location.href = "books";
    }

    if (params.get("msg") === "deleteFail") {
        alert("Xóa sách thất bại!");
		window.location.href = "books";
    }
	
	if (params.get("msg") === "addSuccess") {
		alert("Thành tiền: " + thanhtien);
		window.location.href = "books";
	}
	
	if (params.get("msg") === "addFail") {
	    alert("Thêm sách thất bại!");
		window.location.href = "books?action=add";
	}
	
	if (params.get("msg") === "editSuccess") {
	    alert("Sửa sách thành công!");
		window.location.href = "books";
	}
	
	if (params.get("msg") === "editFail") {
	    alert("Sửa sách thất bại!");
		window.location.href = "books";
	}
	
	if (params.get("msg") === "findFail") {
	    alert("không tìm thấy sách theo mã này!");
		window.location.href = "books";
	}
});
