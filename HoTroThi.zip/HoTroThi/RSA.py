import os

# Bien cuc bo
n, m, d = 0, 0, 0


# Ham tinh nghịch đảo
def timNghichDao2So(a, b):
    a2, b2 = 0, 1
    a3, b3 = a, b
    q, r3, r2 = 0, 0, 0

    while r3 != 1:
        q, r3 = a3 // b3, a3 % b3
        r2 = a2 - b2 * q

        # Đổi chỗ
        a3, b3 = b3, r3
        a2, b2 = b2, r2
    if r2 < 0:
        r2 += a
    return r2


# Hàm kiểm tra số nguyên tố
def KT_SoNT(x):
    if x < 2: return 0
    for i in range(2, x):
        if x % i == 0:
            return 1
    return 0


# Hàm tìm khóa
def timKhoa(p, q, e):
    global n, m, d
    n = p * q
    m = (p - 1) * (q - 1)
    d = timNghichDao2So(m, e)
    Kp = (e, n)
    Ks = (d, p, q)
    key = (Kp, Ks)
    return key


# Hàm mã hóa
def maHoa(e, x):
    return x ** e % n

# Hàm giải mã
def giaiMa(y):
    return y ** d % n

if '__main__' == __name__:
    p,q,e,x = 3,11,7,5

    k = timKhoa(p, q, e)
    y = maHoa(e,x)
    x = giaiMa(y)

    print("Khoa phu va khoa chinh la: ",k)
    print("Ma hoa cua x = 5 la: ",y)
    print("Giai ma: ",x)