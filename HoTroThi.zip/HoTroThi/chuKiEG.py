# Bien toan cuc
y = 0


def TimNghichDao(module, d):
    a3, b3 = module, d
    a2, b2 = 0, 1
    q, r3, r2 = 0, 0, 0

    while r3 != 1:
        q, r3 = a3 // b3, a3 % b3
        r2 = a2 - b2 * q

        # Doi cho
        a3, b3 = b3, r3
        a2, b2 = b2, r2
    if r2 < 0:
        r2 += module
    return r2


def TimKhoa(p, a, x):
    global y

    y = a**x%p
    Kp = (p, a, y)
    Ks = (x)
    Key = (Kp, Ks)
    return Key


def TinKhoa(X, k, p, a, x):
    r = a**k%p
    p -= 1
    kN = TimNghichDao(p, k)
    s = kN * (X - x * r) % p

    # Chung minh chu ky
    Xa = a**X%p
    Xb = y**r*r**s%p
    if Xa == Xb:
        return 'Chu ky hop le'
    return 'Chu ky khong hop le'

if __name__ == '__main__':

    p,a,x,k,X = 11,2,3,7,9

    A = TimKhoa(p,a,x)
    B = TinKhoa(X,k,p,a,x)

    print("Khoa phu va khoa chinh la: ", A)
    print("Ket qua giai ma: ", B)