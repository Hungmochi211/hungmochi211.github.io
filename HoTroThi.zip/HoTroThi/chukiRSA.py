#Bien toan cuc
n,d = 0,0

def TimNghichDao(module, d):
    a3, b3 = module, d
    a2, b2 = 0, 1
    q, r3, r2 = 0, 0, 0

    while r3 != 1:
        q, r3 = a3 // b3, a3 % b3
        r2 = a2 - b2 * q

        # Doi cho
        a3, b3 = b3, r3
        a2, b2 = b2, r2
    if r2 < 0:
        r2 += module
    return r2

def TimKhoa(p,q,e):
    global n,d

    n = p*q
    m = (q-1)*(p-1)
    d = TimNghichDao(m,e)
    Kp = (e,n)
    Ks = (d,p,q)
    Key = (Kp,Ks)
    return Key

def MaHoa(x):
    Sx = x**d%n
    return Sx

def GiaiMa(y,e,x):
    Sy = y**e%n
    if Sy == x:
        return 'Chu ky hop le!'
    return 'Chu ky khong hop!'

if __name__ == '__main__':
    p,q,e,x = 5,7,11,4

    a = TimKhoa(p,q,e)
    b = MaHoa(x)
    c = GiaiMa(b,e,x)

    print("Khoa phu va khoa chinh la: ",a)
    print("Ma hoa cua x =",x," la: ",b)
    print("Ket qua giai ma: ",c)